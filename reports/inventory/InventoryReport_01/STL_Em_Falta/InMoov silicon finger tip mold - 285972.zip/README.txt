InMoov silicon finger tip mold by Gael_Langevin on Thingiverse: https://www.thingiverse.com/thing:285972

Summary:
Here is "InMoov", the robot hand you can print and animate. You have a 3D printer, some building skills, This project is for you!!  This hand is part of my InMoov project, the first 3D printed life-size humanoid, you can reproduce on your home 3D printer.  Blog:http://inmoov.blogspot.comSite:http://www.inmoov.fr   Using your 3D printer to create a little mold to cast silicone finger tips for your robot InMoov.This will give the hands the power to grip anything without dropping it.